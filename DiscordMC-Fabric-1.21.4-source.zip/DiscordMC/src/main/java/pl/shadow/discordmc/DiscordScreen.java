package pl.shadow.discordmc;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.cef.browser.CefBrowser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import com.cinemamod.mcef.MCEF;
import com.cinemamod.mcef.MCEFBrowser;

/** Initial implementation. Uses MCEF's Chromium browser to display Discord Web. */
public final class DiscordScreen extends Screen {
    private MCEFBrowser browser;
    private int panelX, panelY, panelW = 900, panelH = 520;
    private boolean resizing;
    private double lastX, lastY;

    public DiscordScreen() { super(Text.literal("DiscordMC")); }

    @Override
    protected void init() {
        panelW = Math.min(panelW, Math.max(420, width - 20));
        panelH = Math.min(panelH, Math.max(280, height - 20));
        panelX = Math.max(10, (width - panelW) / 2);
        panelY = Math.max(10, (height - panelH) / 2);
        if (browser == null) {
            browser = MCEF.createBrowser("https://discord.com/app", false);
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Otwórz Discord"), b -> {
            if (browser != null) browser.loadURL("https://discord.com/app");
        }).dimensions(panelX + 8, panelY + 6, 130, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Zamknij"), b -> close())
                .dimensions(panelX + panelW - 72, panelY + 6, 64, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xFF202225);
        context.fill(panelX, panelY, panelX + panelW, panelY + 30, 0xFF18191C);
        context.drawText(textRenderer, "DiscordMC — zaloguj się na discord.com", panelX + 150, panelY + 12, 0xFFFFFFFF, false);
        if (browser != null) {
            // Browser rendering/input API is provided by MCEF. Exact render integration can vary by MCEF release.
            browser.render(panelX + 4, panelY + 32, panelW - 8, panelH - 38);
        } else {
            context.drawText(textRenderer, "Uruchamianie przeglądarki Chromium…", panelX + 20, panelY + 50, 0xFFFFFFFF, false);
        }
        context.fill(panelX + panelW - 14, panelY + panelH - 14, panelX + panelW - 4, panelY + panelH - 4, 0xFF5865F2);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && mouseX >= panelX + panelW - 18 && mouseY >= panelY + panelH - 18) {
            resizing = true; lastX = mouseX; lastY = mouseY; return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (resizing && button == 0) {
            panelW = Math.max(420, Math.min(width - panelX - 10, panelW + (int)(mouseX - lastX)));
            panelH = Math.max(280, Math.min(height - panelY - 10, panelH + (int)(mouseY - lastY)));
            lastX = mouseX; lastY = mouseY;
            clearAndInit(); return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && resizing) { resizing = false; return true; }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(null);
    }

    @Override
    public boolean shouldPause() { return false; }
}
