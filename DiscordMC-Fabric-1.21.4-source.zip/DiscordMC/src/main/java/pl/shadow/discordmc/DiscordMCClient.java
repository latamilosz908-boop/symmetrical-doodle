package pl.shadow.discordmc;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class DiscordMCClient implements ClientModInitializer {
    private static KeyBinding openDiscord;

    @Override
    public void onInitializeClient() {
        openDiscord = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.discordmc.open_discord",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                KeyBinding.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openDiscord.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new DiscordScreen());
                } else if (client.currentScreen instanceof DiscordScreen) {
                    client.setScreen(null);
                }
            }
        });
    }
}
