# DiscordMC — Minecraft 1.21.4 / Fabric

Projekt startowy moda, który ma otwierać Discord Web w oknie Minecrafta po naciśnięciu `K`.

## Ważne
To jest **projekt źródłowy / prototyp**, a nie zweryfikowany gotowy plik JAR. Integracja MCEF zmieniała się między wersjami, więc kod renderowania i przekazywania kliknięć może wymagać dopasowania do aktualnego API MCEF oraz kompilacji/testu w grze. Nie podawaj modowi hasła ani tokena ręcznie — logowanie powinno odbywać się na oficjalnej stronie Discorda.

## Wymagania
- Java 21
- Minecraft 1.21.4
- Fabric Loader + Fabric API
- MCEF 2.1.6 dla Fabric 1.21.4

## Budowanie
W folderze projektu uruchom `gradle build` (albo otwórz projekt w IntelliJ IDEA z Gradle). Po udanej kompilacji JAR będzie w `build/libs/`.

MCEF dodaje Chromium do Minecrafta i ma build dla Fabric 1.21.4: https://modrinth.com/mod/mcef
